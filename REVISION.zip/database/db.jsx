import * as SQLite from 'expo-sqlite';

const db = await SQLite.openDatabaseAsync('tienda.db');

export const initDB = async () => {
    await db.execAsync(`
        CREATE TABLE IF NOT EXISTS carrito (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT,
            precio REAL,
            imagen TEXT,
            cantidad INTEGER
        );
        
    `);
}

export default db;