import React, { useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';

import { initDB } from './database/db';
import MainNavigator from './navigation/MainNavigator';



export default function App() {
  useEffect (() => {
    initDB();
  }, []);
  return (
    <NavigationContainer>
      <MainNavigator />
    </NavigationContainer>
  );
}