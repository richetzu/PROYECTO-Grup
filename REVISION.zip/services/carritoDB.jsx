import db from '../database/db';

// FUNCIONES PARA EL CARRITO DE COMPRAS
// AGREGAR AL CARRITO
export const agregarCarrito= async (producto) => {
    const result = await db.getAllAsync(
        'SELECT * FROM carrito WHERE nombre = ?',
        [producto.titulo]
    )
    if (result.length > 0) {
        await db.runAsync(
            'UPDATE carrito SET cantidad = cantidad + 1 WHERE id = ?',
            [producto.id]
        )
    } else 
    {
        await db.runAsync(
            'INSERT INTO carrito (nombre, precio, imagen, cantidad) VALUES (?, ?, ?, ?)',
            [producto.titulo, producto.precio, producto.imagen, 1]
        );
    }
    };
      
// OBTENER TODOS LOS PRODUCTOS DEL CARRITO
export const obtenerCarrito = async () => {
    await db.getAllAsync('SELECT * FROM carrito');
}
// ELIMINAR UN PRODUCTO DEL CARRITO
export const eliminarCarrito = async (id) => {
    await db.runAsync('DELETE FROM carrito WHERE id = ?', [id]);
}
// VACIAR EL CARRITO
export const vaciarCarrito = async () => {
    await db.runAsync('DELETE FROM carrito');
}