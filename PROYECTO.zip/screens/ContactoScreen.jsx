import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function ContactoScreen() {
  return (
    <View>
      <Text>ContactoScreen</Text>
    </View>
  )
}

const styles = StyleSheet.create({})